import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { Apollo, gql } from 'apollo-angular';

const CREATE_USER = gql(`
  mutation {
    createUser(user: {username: $user, password: $pass, email: $email }){
      username
      password
      email
    }
  }
`);

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  username!: string;
  password!: string;
  email!: string;

  constructor(private router:Router) { }

  ngOnInit(): void { }

  onSubmit(loginForm: NgForm) {

    this.email = loginForm.value.email;
    this.username = loginForm.value.username;
    this.password = loginForm.value.password;

    localStorage.setItem('isUserLoggedIn', 'true');
    this.router.navigate(['/hotels']);
    localStorage.setItem('userID', "6031cbb15c5ff52f6c2989dd");


  }

}
