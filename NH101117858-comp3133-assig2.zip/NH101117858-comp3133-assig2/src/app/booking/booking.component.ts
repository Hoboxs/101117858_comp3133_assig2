import { Component, OnInit } from '@angular/core';
import { Apollo, gql } from 'apollo-angular';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';

const CREATE_BOOKING = gql(`
mutation createBooking($hotelID: String!, $bookDate: String!, $bookStart: String!, $bookEnd: String!, $userID: String!){
  createBooking(booking: {hotel_id: $hotelID, booking_date: $bookDate, 
    booking_start: $bookStart, booking_end: $bookEnd, user_id: $userID}){
    hotel_id
    booking_date
    booking_start
    booking_end
    user_id
  }
}
`);

const GET_HOTELS = gql(`
  query($hotelID: String!) {
    find_hotel(hotel_id: $hotelID) {
      hotel_id
      hotel_name
      street
      city
      postal_code
      price
      email
      user_id
    }
  }
`);

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {

  hotels: any[];
  hotelID: string;
  startDate: Date;
  endDate: Date;

  constructor(private apollo: Apollo, private activatedRoute: ActivatedRoute, private router:Router) { }

  ngOnInit(): void {

    
    this.hotelID = this.activatedRoute.snapshot.params.hotel_id;
    console.log(GET_HOTELS)
    this.apollo.watchQuery(
      {query: GET_HOTELS, variables: { hotelID: this.hotelID }}
    ).valueChanges.subscribe((result: any)=>{
      this.hotels = result?.data?.find_hotel;
    })

  }

  onSubmit(bookForm: NgForm) {

    this.startDate = bookForm.value.startDate;
    this.endDate = bookForm.value.endDate;
    let userID = localStorage.getItem('userID');
    let today = new Date;

    this.apollo.mutate(
      {mutation: CREATE_BOOKING, variables: { hotelID: this.hotelID, bookDate: today.toString(), bookStart: this.startDate.toString(), bookEnd: this.endDate.toString(), userID: userID }}
    )
    .subscribe((result: any)=>{

      console.log(result)
      //this.router.navigate(['/hotels']);


    })    

  }

}
