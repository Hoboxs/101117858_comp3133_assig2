import { Component, OnInit } from '@angular/core';
import { Apollo, gql } from 'apollo-angular';
import { NgForm } from '@angular/forms';

const GET_HOTELS = gql(`
  {
    hotels {
      hotel_id
      hotel_name
      street
      city
      postal_code
      price
      email
    }
 }
`);

const GET_BOOKINGS = gql(`
query($userID: String!){
  find_userBookings(user_id: $userID) {
    booking_id
    hotel_id
    booking_date
    booking_start
    booking_end
    user_id
  }
}
`);

const SEARCH_HOTELNAME = gql(`
query($name: String!){
  find_hotelName(hotel_name: $name){
    hotel_name
    street
    city
    postal_code
    price
    email
    user_id
  }
}
`);

const SEARCH_HOTELCITY = gql(`
query($city: String!){
  find_hotelCity(city: $city){
    hotel_name
    street
    city
    postal_code
    price
    email
    user_id
  }
}
`)

@Component({
  selector: 'app-hotels',
  templateUrl: './hotels.component.html',
  styleUrls: ['./hotels.component.css']
})
export class HotelsComponent implements OnInit {

  hotels: any[];
  bookings: any[];
  searchs: any[];
  loading = true;
  error: any;
  searchType: string;
  searchInput: string;

  constructor(private apollo: Apollo) { }

  ngOnInit(): void {

    let userID = localStorage.getItem('userID');

    this.apollo.watchQuery(
      {query: GET_HOTELS}
    ).valueChanges.subscribe((result: any)=>{
      this.hotels = result?.data?.hotels;
    })

    this.apollo.watchQuery(
      {query: GET_BOOKINGS, variables: { userID: userID }}
    ).valueChanges.subscribe((result: any)=>{
      this.bookings = result?.data?.bookings;
      this.loading = result.loading;
      this.error = result.error;
    })
  }

  onSubmit(searchForm: NgForm) {

    this.searchType = searchForm.value.type;
    this.searchInput = searchForm.value.userText;

    console.log(this.searchType)

    if(this.searchType == "name"){

      this.apollo.watchQuery(
        {query: SEARCH_HOTELNAME, variables: { name: this.searchInput.trim() }}
      )
      .valueChanges.subscribe((result: any)=>{        
        this.searchs = result?.data?.find_hotelName;
      })    

  } else {
    this.apollo.watchQuery(
      {query: SEARCH_HOTELCITY, variables: { city: this.searchInput.trim() }}
    )
    .valueChanges.subscribe((result: any)=>{        
      this.searchs = result?.data?.find_hotelCity;
    })   
  }

  }

}
